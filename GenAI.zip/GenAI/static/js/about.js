// Future interactive functionality can go here
console.log("About page loaded");
